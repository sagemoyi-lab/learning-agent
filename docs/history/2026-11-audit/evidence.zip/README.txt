learning-agent 全面深度审查：技术证据包
审查日：2026-11-02
仓库：https://github.com/sagemoyi/learning-agent
固定提交：cb62c7aef96be1f15b5206bf2dc600c2cb636d85

一、怎样读
完整解释、优先级和修复顺序见配套PDF/DOCX。
findings.json含48项正式问题，19 P1、28 P2、1 P3；findings.csv方便排序。
audit下保存外置反例脚本与最终日志。反例断言通过=缺陷成功复现，不表示已修复。
运行现象、静态分析与产品/成熟度建议已在各项中明确区分。

二、目录与路径配置
把本包解压到一个新的审查目录，并在同一目录克隆learning-agent。
目录应为：
  审查目录/configure_paths.py
  审查目录/audit/...
  审查目录/learning-agent/...
先在审查目录执行：python3 configure_paths.py
如需浏览器标记证明，可用：python3 configure_paths.py --chromium /absolute/path/to/chromium
路径配置只更改解出的audit文件，不修改仓库。原始日志中的本次机器路径已换成占位符。
如果需要换一个位置或浏览器路径，请重新解压再配置。

三、安装基线（在learning-agent目录运行）
git checkout cb62c7aef96be1f15b5206bf2dc600c2cb636d85
pnpm install --frozen-lockfile
sh scripts/setup-dsh.sh
pnpm build
pnpm typecheck
pnpm test
pnpm coverage
本轮环境Node v24.22.1、pnpm11.25.0、DSH0.2.0-rc.2。
若本机类型检查堆不足，可设置NODE_OPTIONS=--max-old-space-size=8192。
测试的临时HTTP服务器需要回环监听权限；本轮初始listen EPERM来自审查环境，未计为项目缺陷。
在线Voyage基准2项因无凭据跳过；没有向真实付费服务发送课程内容。

四、外置反例（仍在learning-agent目录）
pnpm exec vitest run --config ../audit/root/vitest.config.mts
pnpm exec vitest run --config ../audit/learning/vitest.config.mjs
pnpm exec vitest run --config ../audit/frontend/vitest-audit.config.mjs
node ../audit/learning/begin-failure-repro.mjs
node ../audit/frontend/async-state-repro.mjs
node ../audit/frontend/chat-repro.mjs
node ../audit/frontend/retitle-repro.mjs
node ../audit/frontend/contrast-repro.mjs
node ../audit/security/repro-input-boundaries.mjs
node ../audit/security/repro-index-disable.mjs
node ../audit/security/repro-parser-switch.mjs
node ../audit/security/repro-xss-browser.mjs

脚本使用Node24的TypeScript剥离支持，需保留固定源码结构。
retitle/async-state/chat脚本动态提取对应函数，并使用最小状态桩；并非完整React/Dockview验收。
BEGIN和文件提交脚本使用故障注入；没有模拟真实硬件断电。
security中的服务替身和回环服务器仅验证各自条件；没有破坏性DoS、OS逃逸或数据外传。
浏览器标记证明仅使用无害DOM属性，拦截所有网络，不把载荷植入真实课程。
测试在临时合成学习目录运行。不要将LEARNING_HOME指向真实学习库来运行审计脚本。

五、结果口径
现有测试：66文件通过、1文件跳过；427项通过、2项跳过。
学习域20条反例；核心/讲义6条；批注3条；另有故障注入和局部脚本。
真实UI：隔离空库DSH，1440/1024/760/390×明暗主题，共8组，51截图逐张检查，74布局采样。
ui-report.json只保留文字结果；截图未打包。空库成功不代表完整学习流程、真实手机或读屏验收。
根pnpm审计：18记录/17不同GHSA。独立DSH审计：15受影响依赖节点。
两种扫描统计不可直接相加；严重度不等于本项目可利用性。部分公告API日期未独立核验。

六、文件与完整性
本包不含真实用户教材、照片、密钥、认证URL、源仓库副本、node_modules、浏览器或字体文件。
checksums.sha256是配置路径前的文件校验和。配置会改变脚本和日志的机器路径，因此校验应先做。
报告的源码链接固定提交；上游.tools/dsh代码由固定安装脚本获得。
这些脚本是审计证据，长期回归应把“缺陷会发生”断言改成正确行为，并放回项目适当测试边界。
