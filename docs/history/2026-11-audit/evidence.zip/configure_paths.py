#!/usr/bin/env python3
"""Configure only this extracted evidence folder; never edit the cloned repository."""
from pathlib import Path
import argparse
p=argparse.ArgumentParser()
p.add_argument('--chromium',help='Absolute path to your Chromium executable, needed only for the browser marker proof')
args=p.parse_args()
base=Path(__file__).resolve().parent
assert (base/'audit').is_dir(), 'Run from the evidence extraction root.'
token='__AUDIT'+'_ROOT__'
changed=0
for f in (base/'audit').rglob('*'):
 if not f.is_file():continue
 try:text=f.read_text()
 except UnicodeError:continue
 new=text
 if args.chromium:
  new=new.replace(token+'/audit/browser-runtime/chromium',str(Path(args.chromium).expanduser().resolve()))
 new=new.replace(token,str(base))
 if new!=text:f.write_text(new);changed+=1
print(f'Configured {changed} evidence files under {base}.')
print('The learning-agent clone must be a sibling of audit in this directory.')
print('Original archive hashes apply before this configuration step.')
