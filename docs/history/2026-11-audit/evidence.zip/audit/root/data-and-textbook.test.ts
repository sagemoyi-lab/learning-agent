import { mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from '../../learning-agent/node_modules/vitest/dist/index.js'
import { Database } from '../../learning-agent/packages/core/src/db.ts'
import { coreMigrations } from '../../learning-agent/packages/core/src/migrations.ts'
import { CoreStore } from '../../learning-agent/packages/core/src/store.ts'
import { precheck, bareTex } from '../../learning-agent/packages/textbook/src/check.ts'
import { handoutCourse, confirm, handoutText, usual, isSection, sectionOf, type HandoutCourse } from '../../learning-agent/tests/textbook/fakes.ts'
import { createHarness, textbookSettled, type Harness } from '../../learning-agent/tests/harness.ts'

const hs: Harness[] = []
afterEach(async () => { for (const h of hs.splice(0)) { await h.settle(); h.dispose() } })

it('R01 file rename survives failed SQLite COMMIT while change log rolls back', async () => {
  const root = mkdtempSync(join(tmpdir(), 'audit-core-'))
  const db = new Database(join(root, 'audit.db'))
  db.migrate('core', coreMigrations)
  const store = new CoreStore(db, root, () => {}, () => ({ create: async () => ({ id: 'audit-workspace' }) }))
  try {
    const course = await store.courses.create({ title: 'Synthetic audit' })
    await store.files.write(course.id, 'goal.md', 'OLD', { actor: 'user', reason: 'audit baseline' })
    const exec = db.sqlite.exec.bind(db.sqlite)
    let fail = true
    db.sqlite.exec = (sql: string) => { if (sql === 'COMMIT' && fail) { fail = false; throw new Error('injected disk/commit failure') }; return exec(sql) }
    await expect(store.files.write(course.id, 'goal.md', 'NEW', { actor: 'system', reason: 'audit write' })).rejects.toThrow('injected')
    expect(readFileSync(join(store.courses.folder(course.id), 'goal.md'), 'utf8')).toBe('NEW')
    expect(store.changes.list({ target: { kind: 'file', courseId: course.id, path: 'goal.md' } })[0]!.after).toBe('OLD')
    console.log('R01', JSON.stringify({ disk: 'NEW', lastRecorded: 'OLD', writeReported: 'failed' }))
  } finally { db.close(); rmSync(root, { recursive: true, force: true }) }
})

it('R02 formula normalization erases exponent/subscript semantics', () => {
  const original = '$p_2=p_1+\\rho gh$'
  const changed = '$p^2=p^1+\\rho gh$'
  expect(bareTex(original)).toBe(bareTex(changed))
  expect(precheck(changed, original, [])).toBeUndefined()
  console.log('R02', JSON.stringify({ original, changed, normalized: bareTex(original), result: 'no issue found' }))
})

it('R03 factual section without any citation is published as not unverified', async () => {
  const course = await handoutCourse(call => isSection(call) ? '静止液体的压强随着高度增加而增大。' : usual(call))
  hs.push(course.h)
  expect(await confirm(course)).toBe('ready')
  const blocks = course.h.ctx.learnTextbook.blocks(course.courseId)
  const matching = []
  for (const b of blocks) {
    const detail = await course.h.ctx.learnTextbook.block(course.courseId, b.id)
    if (detail?.text.includes('随着高度增加')) matching.push(detail)
  }
  expect(matching).toHaveLength(1)
  expect(matching[0]).toMatchObject({ citations: [], unverified: false, original: false })
  console.log('R03', JSON.stringify({ text: matching[0]!.text, citations: matching[0]!.citations, unverified: matching[0]!.unverified }))
})

it('R04 manual block edit has no client base-version precondition', async () => {
  const course = await handoutCourse(usual)
  hs.push(course.h)
  expect(await confirm(course)).toBe('ready')
  const { h, courseId } = course
  const block = h.ctx.learnTextbook.blocks(courseId).find(b => b.lessonId && !b.original)!
  const a = await h.endpoint('textbook', 'blockSource', { courseId, blockId: block.id })
  const b = await h.endpoint('textbook', 'blockSource', { courseId, blockId: block.id })
  expect(a.text).toBe(b.text)
  await h.endpoint('textbook', 'editBlock', { courseId, blockId: block.id, text: '窗口甲保存的重要笔记。' })
  await h.endpoint('textbook', 'editBlock', { courseId, blockId: block.id, text: '窗口乙基于旧内容保存。' })
  const result = await h.ctx.learnTextbook.block(courseId, block.id)
  expect(result!.text).toContain('窗口乙')
  expect(result!.text).not.toContain('窗口甲')
  console.log('R04', JSON.stringify({ bothSavesSucceeded: true, earlierEditLost: true, sourceFields: Object.keys(a) }))
})

it('R05 automatic resume rebases on external edit and overwrites it', async () => {
  let fail = false
  const course = await handoutCourse(call => {
    if (fail && isSection(call) && sectionOf(call).startsWith('1.2.4')) throw new Error('injected interrupted generation')
    return usual(call)
  }, { lessons: [
    { number: '1.2.2', title: '压强的几种表示' },
    { number: '1.2.3', title: '静力学基本方程' },
    { number: '1.2.4', title: '基本方程的应用' },
  ] })
  hs.push(course.h)
  expect(await confirm(course)).toBe('ready')
  fail = true
  await expect(course.h.ctx.learnTextbook.generateStage(course.stage.id)).rejects.toThrow('interrupted')
  const lesson = course.h.ctx.learnCurriculum.lesson(course.lessons[0]!.id)!
  const path = join(course.h.ctx.learnCore.courses.folder(course.courseId), lesson.textbookFile!)
  course.h.ctx.learnCore.db.sqlite.prepare("UPDATE textbook_handouts SET data = json_set(data, '$.state', 'running') WHERE stage_id = ?").run(course.stage.id)
  await course.h.settle()
  hs.splice(hs.indexOf(course.h), 1)
  course.h.dispose(true)
  writeFileSync(path, '我在程序中断以后补写的不可覆盖笔记。\n', 'utf8')
  const resumed = createHarness(usual, { textbook: { webCheck: false } }, { root: course.h.root })
  hs.push(resumed)
  expect(await textbookSettled(resumed.ctx, course.lessons[0]!.id)).toBe('ready')
  const text = readFileSync(path, 'utf8')
  expect(text).not.toContain('不可覆盖笔记')
  console.log('R05', JSON.stringify({ resumeState: 'ready', externalEditOverwritten: true }))
})

it('R06 reindex leaves stale knowledge links after a block changes subject', async () => {
  const course = await handoutCourse(usual, { nodes: [{ title: '压强', core: true }] })
  hs.push(course.h)
  expect(await confirm(course)).toBe('ready')
  const { h, courseId, ids } = course
  const nodeId = ids['压强']!
  const candidates = h.ctx.learnTextbook.blocks(courseId).filter(b => b.nodeIds.includes(nodeId) && !b.original)
  expect(candidates.length).toBeGreaterThan(0)
  const block = candidates[0]!
  await h.endpoint('textbook', 'editBlock', { courseId, blockId: block.id, text: '此处只记录个人学习安排。' })
  const detail = await h.ctx.learnTextbook.block(courseId, block.id)
  expect(detail!.nodeIds).not.toContain(nodeId)
  const links = h.ctx.learnKnowledge.links(nodeId).filter(l => l.target.kind === 'block' && l.target.id === block.id)
  expect(links.length).toBeGreaterThan(0)
  console.log('R06', JSON.stringify({ blockNodes: detail!.nodeIds, staleKnowledgeLinks: links.length }))
})
