const base = '__AUDIT_ROOT__/learning-agent'
const dsh = `${base}/.tools/dsh/node_modules/@deepseek-ai`
export default {
  root: base,
  resolve: { alias: [
    { find: /^@deepseek-ai\/(cordis|dsh-llm|dsh-tools)$/, replacement: `${dsh}/$1/lib/index.js` },
    { find: /^@deepseek-ai\/schemastery$/, replacement: `${dsh}/schemastery/lib/index.mjs` },
  ] },
  test: { include: ['__AUDIT_ROOT__/audit/root/*.test.ts'], testTimeout: 20000 },
}
