import { afterEach, expect, it, vi } from '../../learning-agent/node_modules/vitest/dist/index.js'
import { join } from 'node:path'
import { createHarness, FIXTURES, type Harness } from '../../learning-agent/tests/harness.ts'
import * as assessTools from '../../learning-agent/packages/assess/src/tools.ts'
import * as curriculumTools from '../../learning-agent/packages/curriculum/src/tools.ts'
import { equivalent, judgeByRule } from '../../learning-agent/packages/assess/src/grading.ts'
import { reviewFacts } from '../../learning-agent/packages/curriculum/src/review.ts'

let h: Harness | undefined
const meta = { actor: 'teacher' as const, reason: '独立审查合成复现' }
afterEach(async () => { if (h) { await h.settle(); h.dispose(); h = undefined } })

async function setup() {
  h = createHarness(() => JSON.stringify({ verdict: 'correct', score: 1, confidence: 'high', rationale: '合成判分' }))
  const course = await h.ctx.learnCore.courses.create({ title: '独立审查合成课程' })
  const graph = await h.ctx.learnKnowledge.add(course.id, { nodes: [{ title: '合成知识点', kind: 'skill' }] }, meta)
  const node = graph.nodes[0]!
  return { course, node, ctx: h.ctx }
}

function problem(nodeId: string, extra: Record<string, unknown> = {}) {
  return h!.ctx.learnAssess.addProblems([{
    stem: '合成题：1 + 1 = ?', answer: { kind: 'numeric', value: 2, unit: '', tolerance: { absolute: 0 } },
    answerSource: 'unverified', tier: 4, origin: { kind: 'agent' }, nodeIds: [nodeId], pool: 'practice', ...extra,
  } as never])[0]!
}
async function toolset(courseId: string) {
  const tools = new Map<string, any>()
  h!.ctx.provide('tools', { register: (tool: any) => { tools.set(tool.name, tool); return () => tools.delete(tool.name) } } as never)
  assessTools.apply(h!.ctx)
  curriculumTools.apply(h!.ctx)
  const exec = { agent: { session: { id: await h!.ctx.learnTutor.session(courseId) } } }
  return (name: string, args: unknown) => tools.get(name)!.execute(args, exec)
}

it('AUDIT L01: concurrent submissions append two attempts and two evidence records for one question', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id)
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'quiz', problemIds: [p.id] })
  const answers = [{ problemId: p.id, text: '', finals: ['2'] }]
  await Promise.all([ctx.learnAssess.submit(test.id, answers), ctx.learnAssess.submit(test.id, answers)])
  const attempts = ctx.learnAssess.view(test.id)!.attempts
  const evidence = ctx.learnCore.log.query({ courseId: course.id, types: ['attempt.graded'] })
  expect(attempts.length).toBe(2)
  expect(evidence.length).toBe(2)
  console.log('AUDIT L01', JSON.stringify({ questions: 1, attempts: attempts.length, evidence: evidence.length, state: ctx.learnLearner.states([node.id])[0]?.explanation }))
})

it('AUDIT L01b: retry after interruption duplicates questions already persisted', async () => {
  const { course, node, ctx } = await setup()
  const p1 = problem(node.id), p2 = problem(node.id)
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'quiz', problemIds: [p1.id, p2.id] })
  const store = (ctx.learnAssess as any).store
  const original = store.problem.bind(store)
  store.problem = (id: string) => { if (id === p2.id) throw new Error('synthetic interruption after first question'); return original(id) }
  const answers = [p1, p2].map(p => ({ problemId: p.id, text: '', finals: ['2'] }))
  await expect(ctx.learnAssess.submit(test.id, answers)).rejects.toThrow('synthetic interruption')
  store.problem = original
  expect(ctx.learnAssess.view(test.id)!.test.status).toBe('open')
  await ctx.learnAssess.submit(test.id, answers)
  const attempts = ctx.learnAssess.view(test.id)!.attempts
  expect(attempts.length).toBe(3)
  console.log('AUDIT L01b', JSON.stringify({ questions: 2, attempts: attempts.length }))
})

it('AUDIT L02: source-free authority-labelled model question enters reserved bank via teacher tool', async () => {
  const { course, ctx } = await setup()
  const run = await toolset(course.id)
  await run('add_problems', { problems: [{ stem: '无来源的合成题', answerKind: 'numeric', value: 2, unit: '', answerSource: 'authority', tier: 2, nodes: ['合成知识点'], pool: 'test-reserved' }] })
  const p = ctx.learnAssess.problems({ pool: 'test-reserved' })[0]!
  expect(p.origin.kind).toBe('agent')
  expect(p.answerSource).toBe('authority')
  console.log('AUDIT L02', JSON.stringify({ tier: p.tier, answerSource: p.answerSource, origin: p.origin.kind, pool: p.pool }))
})

it('AUDIT L03: helped answer is assisted in learner but pass in stage report and review facts', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  const stage = stages[0]!
  const test = ctx.learnAssess.startTest({ courseId: course.id, stageId: stage.id, kind: 'stage', blueprint: { core: [{ id: node.id, title: node.title, requires: [], also: [] }], earlier: [], goals: [] } })
  ctx.learnCore.log.append({ type: 'help.given', at: new Date(Date.now() - 1000).toISOString(), courseId: course.id, nodeIds: [node.id], context: { testId: test.id }, problemId: p.id, level: 'answer-revealed', via: 'teacher' })
  const view = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  const state = ctx.learnLearner.states([node.id])[0]!
  const facts = reviewFacts({ stage, view, states: new Map([[node.id, state]]), signals: new Map(), dependents: new Map(), carried: [] })
  expect(state.state).toBe('assisted')
  expect(view.stageReport!.nodes[0]!.outcome).toBe('pass')
  expect(facts.nodes[0]!.result).toBe('pass')
  console.log('AUDIT L03', JSON.stringify({ mastery: state.state, stage: view.stageReport!.nodes[0]!.outcome, review: facts.nodes[0]!.result, recommendation: facts.recommendation }))
})

it('AUDIT L04: explicitly selected stage questions cannot produce a stage review', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  ctx.learnCurriculum.setStatus(stages[0]!.id, 'learning')
  const run = await toolset(course.id)
  await run('start_test', { kind: 'stage', problemIds: [p.id], instructions: '合成阶段测试' })
  const test = ctx.learnAssess.tests(course.id, { kind: 'stage' })[0]!
  await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  expect(ctx.learnCurriculum.stage(stages[0]!.id)!.status).toBe('reviewing')
  expect(ctx.learnAssess.view(test.id)!.stageReport).toBeUndefined()
  await expect(run('save_stage_review', { markdown: '合成复盘', recommend: 'next' })).rejects.toThrow('找不到这个阶段判过分的阶段测试')
  console.log('AUDIT L04', JSON.stringify({ stageStatus: 'reviewing', stageReport: false, saveReview: 'rejected' }))
})

it('AUDIT L05: expression probing accepts a non-identity outside positive sample interval', () => {
  expect(equivalent('sqrt(x^2)', 'x')).toBe(true)
  const graded = judgeByRule({ kind: 'expression', value: 'x' }, 'sqrt(x^2)')
  expect(graded!.verdict).toBe('correct')
  console.log('AUDIT L05', JSON.stringify({ given: 'sqrt(x^2)', reference: 'x', verdict: graded!.verdict, counterexample: 'x=-1: 1 != -1' }))
})

it('AUDIT L06: parallel section extraction duplicates same named identity', async () => {
  h = createHarness(call => JSON.stringify({ nodes: [{ title: '共同概念', kind: 'knowledge', sources: [/\[(ck_[0-9A-Z]{26})\]/.exec(call.prompt)![1]] }], edges: [] }))
  const { ctx } = h
  const course = await ctx.learnCore.courses.create({ title: '并行知识抽取合成课程' })
  const fixture = join(FIXTURES, 'retrieval-chapter')
  const source = await ctx.learnLibrary.importParsed({ title: '检索合成资料', kind: 'textbook', authority: '1', file: join(fixture, 'source.md'), parsed: [join(fixture, 'middle.json')], courseId: course.id })
  const k = ctx.learnKnowledge
  const starts = k.extract(course.id, ['1.1', '1.2'], 'learner', source.id)
  await Promise.all(starts.map(start => new Promise<void>(done => {
    const sections = (k as any).sections
    if (['done', 'failed', 'canceled'].includes(sections.get(start.job!.id)?.status)) return done()
    const off = ctx.on('learning/extraction-changed', job => { if (job.id === start.job!.id && ['done', 'failed', 'canceled'].includes(job.status)) { off(); done() } })
  })))
  const matches = k.graph(course.id).nodes.filter(node => node.title === '共同概念')
  expect(matches.length).toBe(2)
  expect(() => k.resolve(course.id, '共同概念')).toThrow('同名或别名对应多个知识节点')
  console.log('AUDIT L06', JSON.stringify({ jobs: starts.length, sameNameNodes: matches.length, resolve: 'ambiguous' }))
})

it('AUDIT L07: revising a learning stage clears confirmation but cannot be confirmed again', async () => {
  const { course, ctx } = await setup()
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  const id = stages[0]!.id
  await ctx.learnCurriculum.saveDesign(id, { markdown: '合成设计', lessons: [{ number: '1.1', title: '第一节' }] }, meta)
  const curriculumStore = (ctx.learnCurriculum as any).store
  curriculumStore.saveStage({ ...ctx.learnCurriculum.stage(id), designConfirmedAt: new Date().toISOString() })
  ctx.learnCurriculum.setStatus(id, 'learning')
  await ctx.learnCurriculum.saveDesign(id, { markdown: '改过的合成设计', lessons: [{ number: '1.1', title: '改过的第一节' }] }, meta)
  const stage = ctx.learnCurriculum.stage(id)!
  expect(stage.status).toBe('learning')
  expect(stage.designConfirmedAt).toBeUndefined()
  await expect(ctx.learnCurriculum.confirmDesign(id)).rejects.toThrow('没有待确认的设计')
  console.log('AUDIT L07', JSON.stringify({ stageStatus: stage.status, designConfirmed: false, confirmAgain: 'rejected' }))
})

it('AUDIT L08: teacher withdrawal exposes answer without marking reserved question as seen', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'stage', problemIds: [p.id] })
  const withdrawn = ctx.learnAssess.withdraw(test.id)
  expect(withdrawn.problems[0]!.answer).toBeDefined()
  const next = ctx.learnAssess.startTest({ courseId: course.id, kind: 'stage', blueprint: { core: [{ id: node.id, title: node.title, requires: [], also: [] }], earlier: [], goals: [] } })
  expect(next.plan!.fresh).toContain(p.id)
  console.log('AUDIT L08', JSON.stringify({ answerOnWithdrawnTest: true, automaticallyReusedAsFresh: next.plan!.fresh.includes(p.id) }))
})

it('AUDIT L09: mutable problem changes historical answer while original verdict stays', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id)
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'quiz', problemIds: [p.id] })
  await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  ctx.learnAssess.reviewProblem(p.id, 'fixed', '合成更正参考答案', { answer: { kind: 'numeric', value: 99, unit: '', tolerance: { absolute: 0 } } })
  const view = ctx.learnAssess.view(test.id)!
  expect(view.attempts[0]!.finals).toEqual(['2'])
  expect(view.attempts[0]!.grading!.verdict).toBe('correct')
  expect((view.problems[0]!.answer as any).value).toBe(99)
  console.log('AUDIT L09', JSON.stringify({ submitted: 2, originalVerdict: 'correct', historicalPageReference: 99 }))
})

it('AUDIT L10: concurrent same-version goal revisions both succeed and lose one change', async () => {
  const { course, ctx } = await setup()
  const saved = await ctx.learnGoal.saveDraft(course.id, {
    purpose: '合成目标', scenario: '合成资料短题', canDo: ['按给定参数计算静水压强'], level: '能独立完成资料中的计算', verification: '小测',
    boundaries: { exclude: ['资料以外的内容'], defaultConditions: { book: 'closed', calculator: true, formulaSheet: false } },
  }, '# 目标说明\n\n仅用于测试。\n', meta)
  const version = saved.doc.goal.version
  const results = await Promise.all([
    ctx.learnGoal.revise(course.id, version, { purpose: '并发修改后的学习目的' }, meta),
    ctx.learnGoal.revise(course.id, version, { level: '并发修改后的完成水平' }, meta),
  ])
  const final = (await ctx.learnGoal.get(course.id))!.goal
  expect(results.map(result => result.doc.goal.version)).toEqual([version + 1, version + 1])
  expect(final.purpose === '并发修改后的学习目的' && final.level === '并发修改后的完成水平').toBe(false)
  console.log('AUDIT L10', JSON.stringify({ acceptedVersions: results.map(result => result.doc.goal.version), finalPurpose: final.purpose, finalLevel: final.level, lostOneChange: true }))
})

it('AUDIT L11: numeric parser grades just a prefix and drops units for percent reference', () => {
  const plain = { kind: 'numeric' as const, value: 2, unit: '', tolerance: { absolute: 0 } }
  const percent = { kind: 'numeric' as const, value: 20, unit: '%', tolerance: { absolute: 0 } }
  expect(judgeByRule(plain, '2+100')!.verdict).toBe('correct')
  expect(judgeByRule(plain, '2 kg')!.verdict).toBe('correct')
  expect(judgeByRule(percent, '20 kg')!.verdict).toBe('correct')
  console.log('AUDIT L11', JSON.stringify({ cases: [
    { reference: '2', given: '2+100', verdict: judgeByRule(plain, '2+100')!.verdict },
    { reference: '2 (dimensionless)', given: '2 kg', verdict: judgeByRule(plain, '2 kg')!.verdict },
    { reference: '20%', given: '20 kg', verdict: judgeByRule(percent, '20 kg')!.verdict },
  ] }))
})

it('AUDIT L12: partly wrong multipart diagnosis reports known instead of an unknown boundary', async () => {
  const { course, node, ctx } = await setup()
  const part = { kind: 'numeric', value: 2, unit: '', tolerance: { absolute: 0 } }
  const p = problem(node.id, { answer: { kind: 'parts', parts: [{ label: '(1)', answer: part }, { label: '(2)', answer: part }] } })
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'diagnostic', problemIds: [p.id], scope: [{ id: node.id, title: node.title, requires: [], also: [] }] })
  const view = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2', '999'] }])
  expect(view.attempts[0]!.grading!.verdict).toBe('partial')
  expect(view.diagnosis!.nodes[0]!.state).toBe('known')
  expect(ctx.learnLearner.states([node.id])[0]!.state).toBe('not-yet')
  console.log('AUDIT L12', JSON.stringify({ partVerdicts: view.attempts[0]!.grading!.parts!.map(part => part.verdict), diagnosis: view.diagnosis!.nodes[0]!.state, mastery: ctx.learnLearner.states([node.id])[0]!.state }))
})

it('AUDIT L03b: late help log correctly recomputes learner but stage pass persists', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'stage', blueprint: { core: [{ id: node.id, title: node.title, requires: [], also: [] }], earlier: [], goals: [] } })
  const before = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  expect(ctx.learnLearner.states([node.id])[0]!.state).toBe('independent')
  ctx.learnCore.log.append({ type: 'help.given', at: new Date(Date.parse(before.attempts[0]!.submittedAt) - 1000).toISOString(), courseId: course.id, nodeIds: [node.id], context: { testId: test.id }, problemId: p.id, level: 'answer-revealed', via: 'teacher' })
  expect(ctx.learnLearner.states([node.id])[0]!.state).toBe('assisted')
  expect(ctx.learnAssess.view(test.id)!.stageReport!.nodes[0]!.outcome).toBe('pass')
  console.log('AUDIT L03b', JSON.stringify({ beforeLateHelp: 'independent', afterLateHelp: 'assisted', stageAfterLateHelp: 'pass' }))
})

it('AUDIT L13: grading delay is counted as learner overtime', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id)
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'quiz', problemIds: [p.id], conditions: { book: 'closed', calculator: true, formulaSheet: false, timeLimit: 1 } })
  vi.useFakeTimers({ now: new Date('2026-11-02T05:00:00.000Z') })
  try {
    ctx.learnAssess.begin(test.id)
    vi.setSystemTime(new Date('2026-11-02T05:00:59.000Z'))
    const assess = ctx.learnAssess as any
    const original = assess.grade.bind(assess)
    assess.grade = async (...args: any[]) => { const grading = await original(...args); vi.setSystemTime(new Date('2026-11-02T05:02:30.000Z')); return grading }
    const view = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
    expect(view.attempts[0]!.submittedAt).toBe('2026-11-02T05:00:59.000Z')
    expect(view.test.overtime).toBe(1)
    console.log('AUDIT L13', JSON.stringify({ openedAt: view.test.openedAt, submittedAt: view.attempts[0]!.submittedAt, deadline: '2026-11-02T05:01:00.000Z', endedAt: view.test.endedAt, reportedOvertimeMinutes: view.test.overtime }))
  } finally { vi.useRealTimers() }
})

it('AUDIT L14: merging a stage node leaves normal stage test assembly bound to the retired identity', async () => {
  const { course, node, ctx } = await setup()
  const added = await ctx.learnKnowledge.add(course.id, { nodes: [{ title: '保留的知识身份', kind: 'skill' }] }, meta)
  const keep = added.nodes.find(item => item.title === '保留的知识身份')!
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  const stage = stages[0]!
  await ctx.learnCurriculum.saveDesign(stage.id, { markdown: '合成阶段设计', lessons: [{ number: '1.1', title: '合成课时' }], nodeIds: [node.id] }, meta)
  ctx.learnKnowledge.merge({ keepId: keep.id, keepVersion: keep.version, mergeId: node.id, mergeVersion: node.version }, { actor: 'user', reason: '合成身份合并' })
  const p = problem(keep.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const run = await toolset(course.id)
  await expect(run('start_test', { kind: 'stage', instructions: '按既定阶段设计测试' })).rejects.toThrow('没有本阶段核心知识点的新题')
  expect(ctx.learnCurriculum.stage(stage.id)!.nodeIds).toEqual([node.id])
  expect(ctx.learnKnowledge.identity(node.id).current).toBe(keep.id)
  console.log('AUDIT L14', JSON.stringify({ stageStillUsesMergedId: true, freshReservedQuestionOnCurrentIdentity: p.id, normalStageTest: 'no-problems' }))
})

it('AUDIT L03c: fixed problem voids mastery evidence but still passes stage review', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  const stage = stages[0]!
  const test = ctx.learnAssess.startTest({ courseId: course.id, stageId: stage.id, kind: 'stage', blueprint: { core: [{ id: node.id, title: node.title, requires: [], also: [] }], earlier: [], goals: [] } })
  const initial = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  vi.useFakeTimers({ now: Date.parse(initial.attempts[0]!.submittedAt) + 1000 })
  try { ctx.learnAssess.reviewProblem(p.id, 'fixed', '发现原参考答案有误', { answer: { kind: 'numeric', value: 99, unit: '', tolerance: { absolute: 0 } } }) }
  finally { vi.useRealTimers() }
  const view = ctx.learnAssess.view(test.id)!
  const state = ctx.learnLearner.states([node.id])[0]!
  const facts = reviewFacts({ stage, view, states: new Map([[node.id, state]]), signals: new Map(), dependents: new Map(), carried: [] })
  expect(state.state).toBe('untested')
  expect(state.explanation).toContain('不计')
  expect(facts.nodes[0]!.result).toBe('pass')
  console.log('AUDIT L03c', JSON.stringify({ masteryAfterFixed: state.state, evidenceExplanation: state.explanation, stage: view.stageReport!.nodes[0]!.outcome, review: facts.nodes[0]!.result, recommendation: facts.recommendation }))
})

it('AUDIT L15: regrading after a saved review leaves a stale pass decision and no carried risk', async () => {
  const { course, node, ctx } = await setup()
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务' }], meta)
  const stage = stages[0]!
  ctx.learnCurriculum.setStatus(stage.id, 'learning')
  const run = await toolset(course.id)
  await run('start_test', { kind: 'stage', nodes: [node.title], instructions: '合成阶段验收' })
  const test = ctx.learnAssess.tests(course.id, { kind: 'stage' })[0]!
  const view = await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  await run('save_stage_review', { markdown: '基于当前判分保存的合成复盘', recommend: 'next' })
  ctx.learnAssess.regrade(view.attempts[0]!.id, 'incorrect', '复核后发现初判错误')
  expect(ctx.learnAssess.view(test.id)!.stageReport!.nodes[0]!.outcome).toBe('fail')
  expect(ctx.learnCurriculum.stage(stage.id)!.review!.nodes[0]!.result).toBe('pass')
  await ctx.learnCurriculum.decideReview(stage.id, 'next')
  expect(ctx.learnCurriculum.carried(course.id)).toEqual([])
  console.log('AUDIT L15', JSON.stringify({ liveStageResult: 'fail', savedReviewResult: 'pass', decisionAccepted: 'next', carriedRiskCount: 0 }))
})

it('AUDIT L16: replacing a final question does not update goal item references', async () => {
  const { course, node, ctx } = await setup()
  const p1 = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const p2 = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const test = ctx.learnAssess.startTest({ courseId: course.id, kind: 'final', final: { items: [{ key: 'can-1', text: '完成合成任务', nodes: [{ id: node.id, title: node.title, requires: [], also: [] }] }], risks: [], stageIds: [] } })
  expect(test.problemIds).toEqual([p1.id])
  const swapped = ctx.learnAssess.report(test.id, p1.id, 'done-before', '合成换题')
  expect(swapped.test.problemIds).toEqual([p2.id])
  const view = await ctx.learnAssess.submit(test.id, [{ problemId: p2.id, text: '', finals: ['2'] }])
  expect(view.attempts[0]!.grading!.verdict).toBe('correct')
  expect(view.finalReport!.items[0]!.outcome).toBe('insufficient')
  expect(view.finalReport!.items[0]!.problems).toEqual([])
  console.log('AUDIT L16', JSON.stringify({ replacementAnswer: 'correct', finalGoalOutcome: 'insufficient', finalGoalProblems: [], planStillPointsAtWithdrawnQuestion: view.test.final!.items[0]!.problemIds[0] === p1.id }))
})

it('AUDIT L17: old final certifies a materially revised same-key goal without retesting', async () => {
  const { course, node, ctx } = await setup()
  const saved = await ctx.learnGoal.saveDraft(course.id, {
    purpose: '合成目标', scenario: '合成资料短题', canDo: ['按给定参数计算静水压强'], level: '能独立完成资料中的计算', verification: '小测',
    boundaries: { exclude: ['资料以外的内容'], defaultConditions: { book: 'closed', calculator: true, formulaSheet: false } },
  }, '# 目标说明\n\n仅用于测试。\n', meta)
  const key = saved.doc.goal.canDo[0]!.key
  await ctx.learnGoal.confirm(course.id)
  const { stages } = await ctx.learnCurriculum.saveRoadmap(course.id, [{ title: '合成阶段', objective: '完成合成任务', supports: [key] }], meta)
  const stage = stages[0]!
  await ctx.learnCurriculum.saveDesign(stage.id, { markdown: '合成阶段设计', lessons: [{ number: '1.1', title: '合成课时' }], nodeIds: [node.id] }, meta)
  ctx.learnCurriculum.setStatus(stage.id, 'done')
  const p = problem(node.id, { answerSource: 'authority', tier: 2, pool: 'test-reserved' })
  const run = await toolset(course.id)
  await run('start_test', { kind: 'final', instructions: '旧目标的结课检验' })
  const test = ctx.learnAssess.tests(course.id, { kind: 'final' })[0]!
  await ctx.learnAssess.submit(test.id, [{ problemId: p.id, text: '', finals: ['2'] }])
  const before = (await ctx.learnGoal.get(course.id))!
  const revisedText = '独立设计完整传热网络并优化运行参数'
  await ctx.learnGoal.revise(course.id, before.goal.version, { canDo: [{ key, text: revisedText }] }, meta)
  await ctx.learnGoal.confirm(course.id)
  await run('save_course_report', { markdown: '针对新版目标保存的合成报告' })
  const report = (await ctx.learnCurriculum.report(course.id))!
  expect(report.items[0]!.text).toBe(revisedText)
  expect(report.items[0]!.status).toBe('done')
  expect(ctx.learnAssess.tests(course.id, { kind: 'final' })).toHaveLength(1)
  console.log('AUDIT L17', JSON.stringify({ originallyTestedGoal: test.final!.items[0]!.text, reportedGoal: report.items[0]!.text, reportStatus: report.items[0]!.status, finalCount: 1 }))
})
