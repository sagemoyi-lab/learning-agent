import original from '../../learning-agent/vitest.config.ts'
export default {
  ...original,
  root: '__AUDIT_ROOT__/learning-agent',
  test: { ...original.test, include: ['__AUDIT_ROOT__/audit/learning/domain-repro.test.ts'], coverage: { enabled: false }, testTimeout: 15000 }
}
