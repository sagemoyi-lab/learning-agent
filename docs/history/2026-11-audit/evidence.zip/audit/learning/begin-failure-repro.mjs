import assert from 'node:assert/strict'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Database } from '../../learning-agent/packages/core/src/db.ts'

// A single injected SQLITE_BUSY-like BEGIN failure. No repository or real data is modified.
const root = mkdtempSync(join(tmpdir(), 'audit-begin-'))
const db = new Database(join(root, 'audit.db'))
try {
  db.sqlite.exec('CREATE TABLE audit_rows (id INTEGER PRIMARY KEY, text TEXT NOT NULL)')
  const original = db.sqlite.exec.bind(db.sqlite)
  let failBegin = true
  db.sqlite.exec = sql => {
    if (sql === 'BEGIN IMMEDIATE' && failBegin) {
      failBegin = false
      throw new Error('synthetic database is locked before BEGIN')
    }
    return original(sql)
  }
  let callbackRan = false
  assert.throws(() => db.transaction(() => { callbackRan = true }), /database is locked/)
  assert.equal(callbackRan, false)
  db.sqlite.exec = original

  const emitted = []
  assert.throws(() => db.transaction(() => {
    db.sqlite.prepare('INSERT INTO audit_rows VALUES (?, ?)').run(1, 'must roll back')
    db.afterCommit(() => emitted.push('row 1 committed'))
    throw new Error('synthetic later callback failure')
  }), /later callback failure/)
  const rowsAfterFailedTransaction = db.sqlite.prepare('SELECT * FROM audit_rows ORDER BY id').all()
  assert.equal(rowsAfterFailedTransaction.length, 1)
  assert.deepEqual(emitted, [])

  db.transaction(() => {
    db.sqlite.prepare('INSERT INTO audit_rows VALUES (?, ?)').run(2, 'healthy request after failure')
    db.afterCommit(() => emitted.push('row 2 committed'))
  })
  const rowsAfterHealthyTransaction = db.sqlite.prepare('SELECT * FROM audit_rows ORDER BY id').all()
  assert.equal(rowsAfterHealthyTransaction.length, 2)
  assert.deepEqual(emitted, [])
  console.log(JSON.stringify({
    id: 'DATA-05',
    initialBeginRejected: true,
    initialCallbackRan: callbackRan,
    persistedRowsAfterSubsequentFailedTransaction: rowsAfterFailedTransaction,
    persistedRowsAfterNextHealthyTransaction: rowsAfterHealthyTransaction,
    deliveredAfterCommitEvents: emitted,
    result: 'assertions reproduced broken rollback and indefinitely queued afterCommit after one BEGIN failure',
  }, null, 2))
} finally {
  db.close()
  rmSync(root, { recursive: true, force: true })
}
