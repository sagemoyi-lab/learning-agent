import fs from 'node:fs/promises'
import { createRequire } from 'node:module'
const root = '__AUDIT_ROOT__/learning-agent'
const require = createRequire(`${root}/package.json`)
const { transformSync } = require('esbuild')
const harness = await fs.readFile('__AUDIT_ROOT__/audit/frontend/async-state-repro.mjs', 'utf8')
const harnessBody = harness.slice(harness.indexOf('const equal ='), harness.indexOf('const defer ='))
const HookHost = new Function(`${harnessBody}; return HookHost`)()
const src = await fs.readFile(`${root}/packages/kit/src/client/chat.tsx`, 'utf8')
const basics = src.slice(src.indexOf('type Item ='), src.indexOf('/** Grow a text area'))
const chatBody = src.slice(src.indexOf('export function Chat('), src.indexOf('  const conversation ='))
  .replace('export function Chat', 'function Chat') + '\nreturn { items, loaded, live, busy, draft, error, send };\n}'
const code = transformSync(basics + chatBody, { loader: 'ts', format: 'cjs', target: 'es2022' }).code
const host = new HookHost()
const Chat = new Function('useState', 'useRef', 'useEffect', 'useLayoutEffect', 'sendPrompt', `${code}; return Chat`)(host.useState, host.useRef, host.useEffect, host.useEffect, async (remote, id, text) => {
  const result = await remote.prompt({ sessionId: id, text })
  if (!result.ok) throw new Error('prompt failed')
})
let followCalls = 0, promptCalls = 0, available = false
const remote = {
  async *follow() {
    followCalls++
    yield { type: 'snapshot', records: [] }
    yield { type: 'event', event: { type: 'turn/start', seq: 1 } }
    if (!available) throw new Error('simulated carrier interruption')
  },
  prompt: async () => { promptCalls++; return { ok: true } },
}
host.component = () => Chat({ shell: {}, remote, sessionId: 'session-a', placeholder: 'Ask' })
host.render(); await host.settle(); await host.settle()
const afterDisconnect = { followCalls, busy: host.result.busy, error: host.result.error }
available = true
host.render(); await host.settle()
const afterCarrierRecovers = { followCalls, busy: host.result.busy, error: host.result.error }
await host.result.send('New question after reconnect'); await host.settle()
const afterSuccessfulSend = { followCalls, promptCalls, busy: host.result.busy, error: host.result.error ?? null }
const dshPath = `${root}/.tools/dsh/node_modules/@deepseek-ai/dsh-api-session-controller`
const dsh = await fs.readFile(`${dshPath}/lib/index.js`, 'utf8')
const { isAppendSurfaceEvent } = await import(`${root}/.tools/dsh/node_modules/@deepseek-ai/dsh-session/lib/index.js`)
const paginateText = dsh.slice(dsh.indexOf('function paginate('), dsh.indexOf('/** Translate current logical Session metadata'))
const paginate = new Function('SessionLogOffset', 'isAppendSurfaceEvent', 'MESSAGE_TYPES$1', `${paginateText}; return paginate`)(n => n, isAppendSurfaceEvent, new Set(['user/message', 'assistant/message']))
const count = Number(dsh.match(/const DEFAULT_MAX_MESSAGES = (\d+)/)[1])
const events = Array.from({ length: 60 }, (_, seq) => ({ seq, type: seq % 2 ? 'assistant/message' : 'user/message', data: { content: [{ type: 'text', text: `Message ${seq}` }] }, surfaceOp: 'append' }))
const page = paginate(events, undefined, count, events.length - 1)
const output = {
  methodology: 'Unmodified Chat state/effect code with JSX return replaced by state inspection, same limited hook harness; real installed pinned DSH paginate implementation and isAppendSurfaceEvent; not a full React/browser test.',
  afterDisconnect, afterCarrierRecovers, afterSuccessfulSend,
  historyWindow: { packageVersion: JSON.parse(await fs.readFile(`${dshPath}/package.json`, 'utf8')).version, defaultMaxMessages: count, existingMessages: events.length, returnedMessages: page.events.length, firstReturnedSeq: page.events[0]?.seq, hasMore: page.hasMore, applicationExposesPageMethod: /\bpage\(/.test(src), applicationReadsHasMore: /hasMore/.test(src) },
}
await fs.writeFile('__AUDIT_ROOT__/audit/frontend/chat-result.json', JSON.stringify(output, null, 2) + '\n')
console.log(JSON.stringify(output, null, 2))
