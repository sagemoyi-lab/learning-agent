import fs from 'node:fs/promises'
const linear = value => { const s = value / 255; return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4 }
const luminance = hex => { const c = hex.slice(1).match(/../g).map(v => linear(parseInt(v, 16))); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2] }
const ratio = (a, b) => { const x = luminance(a), y = luminance(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05) }
const cases = [
  { name: 'light text3 on page', fg: '#8c8a83', bg: '#ffffff' },
  { name: 'light text3 on chrome', fg: '#8c8a83', bg: '#f7f7f4' },
  { name: 'dark text3 on page', fg: '#807e78', bg: '#1b1b1a' },
  { name: 'dark text3 on raised', fg: '#807e78', bg: '#232321' },
].map(item => ({ ...item, ratio: ratio(item.fg, item.bg) }))
await fs.writeFile('__AUDIT_ROOT__/audit/frontend/contrast.json', JSON.stringify(cases, null, 2) + '\n')
console.log(JSON.stringify(cases, null, 2))
