import { describe, it, expect, vi } from '__AUDIT_ROOT__/learning-agent/node_modules/vitest/dist/index.js'
import { writeFileSync } from 'node:fs'
import { createHarness } from '__AUDIT_ROOT__/learning-agent/tests/harness.ts'
import { locateQuote, placeAnnotation } from '__AUDIT_ROOT__/learning-agent/packages/annotation/src/anchor.ts'
const output: Record<string, unknown> = {}
const save = () => writeFileSync('__AUDIT_ROOT__/audit/frontend/annotation-result.json', JSON.stringify(output, null, 2) + '\n')
const FILE = 'stages/st_synthetic/textbook/1.1.md'
const meta = { actor: 'teacher' as const, reason: 'audit synthetic only' }
const setup = async (text: string) => {
  const h = createHarness(() => { throw new Error('Model invocation prohibited in audit') })
  const { id: courseId } = await h.endpoint('core', 'createCourse', { title: 'Synthetic annotation audit' })
  const write = async (body: string) => {
    await h.ctx.learnCore.files.write(courseId, FILE, `# Synthetic\n\n${body} ^aaa111\n`, meta)
    await h.settle()
  }
  await write(text)
  return { h, courseId, write }
}
describe('audit-only characterization: observed bugs, not expected acceptance behavior', () => {
  it('a negation inserted at the beginning remains silently anchored', () => {
    const quote = { exact: '能忽略摩擦损失', prefix: '', suffix: '。' }
    const initial = locateQuote('能忽略摩擦损失。', quote)
    const changed = locateQuote('不能忽略摩擦损失。', quote)
    output.boundaryNegation = { initial, changed, expected: 'needs-confirmation' }
    expect(changed.status).toBe('anchored')
    save()
  })
  it('location recomputation overwrites a concurrently edited and hidden note', async () => {
    const { h, courseId, write } = await setup('这里能忽略摩擦损失。')
    try {
      const note = await h.endpoint('annotation', 'create', { courseId, type: 'question', text: '旧批注', anchor: { kind: 'block', courseId, blockId: 'aaa111', quote: { exact: '能忽略摩擦损失', prefix: '这里', suffix: '。' } } })
      await write('这里不能忽略摩擦损失。')
      let release!: () => void, entered!: () => void
      const gate = new Promise<void>(resolve => { release = resolve })
      const ready = new Promise<void>(resolve => { entered = resolve })
      const original = h.ctx.learnTextbook.block.bind(h.ctx.learnTextbook)
      const spy = vi.spyOn(h.ctx.learnTextbook, 'block').mockImplementationOnce(async (...args) => { entered(); await gate; return original(...args) })
      const loading = h.ctx.learnAnnotation.list({ courseId })
      await ready
      h.ctx.learnAnnotation.edit(note.id, { text: '用户刚刚保存的新批注' })
      h.ctx.learnAnnotation.setHidden(note.id, true)
      const afterUserAction = h.ctx.learnAnnotation.get(note.id)
      release(); await loading
      const afterListCompleted = h.ctx.learnAnnotation.get(note.id)
      output.listLostUpdate = { afterUserAction: { text: afterUserAction?.text, hidden: !!afterUserAction?.hiddenAt }, afterListCompleted: { text: afterListCompleted?.text, hidden: !!afterListCompleted?.hiddenAt, location: afterListCompleted?.location.status } }
      expect(afterListCompleted?.text).toBe('旧批注')
      expect(afterListCompleted?.hiddenAt).toBeUndefined()
      spy.mockRestore()
      save()
    } finally { h.dispose() }
  })
  it('concurrent error submission makes two proposals for one note', async () => {
    const { h, courseId, write } = await setup('压强相同。压强相同。')
    try {
      const note = await h.endpoint('annotation', 'create', { courseId, type: 'error', text: '条件有误', anchor: { kind: 'block', courseId, blockId: 'aaa111', quote: { exact: '压强相同', prefix: '', suffix: '' } } })
      expect(note.proposalId).toBeUndefined()
      await write('压强相同。')
      const results = await Promise.all([h.ctx.learnAnnotation.submitError(note.id), h.ctx.learnAnnotation.submitError(note.id)])
      const proposals = h.ctx.learnCore.proposals.list({ courseId })
      output.duplicateProposal = { returnedIds: results.map(p => p.id), proposalCount: proposals.length, linkedId: h.ctx.learnAnnotation.get(note.id)?.proposalId, expectedProposalCount: 1 }
      expect(new Set(results.map(p => p.id)).size).toBe(2)
      expect(proposals).toHaveLength(2)
      save()
    } finally { h.dispose() }
  })
})
