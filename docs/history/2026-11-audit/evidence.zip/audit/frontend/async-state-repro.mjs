import fs from 'node:fs/promises'
import { createRequire } from 'node:module'
const root = '__AUDIT_ROOT__/learning-agent'
const require = createRequire(`${root}/package.json`)
const { transformSync } = require('esbuild')
const transpile = code => transformSync(code, { loader: 'ts', format: 'cjs', target: 'es2022' }).code
const kit = await fs.readFile(`${root}/packages/kit/src/client.ts`, 'utf8')
const hookCode = kit.slice(kit.indexOf('export function useLoad'), kit.indexOf('/** Run an action'))
  .replace('export function useLoad', 'function useLoad')
const equal = (a, b) => a && b && a.length === b.length && a.every((x, i) => Object.is(x, b[i]))
// Only React state/ref/effect/callback semantics needed by the unchanged useLoad implementation.
// This is an isolated algorithm reproduction, not a real DOM/React/browser test.
class HookHost {
  slots = []; cursor = 0; pending = []; dirty = false
  useState = initial => {
    const i = this.cursor++
    this.slots[i] ??= { value: typeof initial === 'function' ? initial() : initial }
    return [this.slots[i].value, value => {
      this.slots[i].value = typeof value === 'function' ? value(this.slots[i].value) : value
      this.dirty = true
    }]
  }
  useRef = value => { const i = this.cursor++; return this.slots[i] ??= { current: value } }
  useCallback = (fn, deps) => {
    const i = this.cursor++; const old = this.slots[i]
    if (!old || !equal(old.deps, deps)) this.slots[i] = { fn, deps }
    return this.slots[i].fn
  }
  useEffect = (fn, deps) => {
    const i = this.cursor++; const old = this.slots[i]
    if (!old || !equal(old.deps, deps)) {
      this.slots[i] = { deps, cleanup: old?.cleanup }
      this.pending.push(() => {
        this.slots[i].cleanup?.()
        this.slots[i].cleanup = fn()
      })
    }
  }
  render() {
    this.cursor = 0; this.dirty = false
    this.result = this.component()
    for (const effect of this.pending.splice(0)) effect()
    return this.result
  }
  async settle() {
    for (let i = 0; i < 5; i++) {
      await Promise.resolve()
      if (this.dirty) this.render()
    }
    return this.result
  }
}
const defer = () => {
  let resolve, reject
  const promise = new Promise((ok, fail) => { resolve = ok; reject = fail })
  return { promise, resolve, reject }
}
const make = () => {
  const host = new HookHost()
  const useLoad = new Function('useState', 'useRef', 'useCallback', 'useEffect', 'describeError', `${transpile(hookCode)}; return useLoad`)(host.useState, host.useRef, host.useCallback, host.useEffect, e => e.message)
  const listeners = new Set()
  const shell = { usePage: () => ({ visible: true }), onFeed: fn => { listeners.add(fn); return () => listeners.delete(fn) } }
  return { host, useLoad, shell, listeners }
}
const empty = make(); let calls = 0
empty.host.component = () => empty.useLoad(empty.shell, async () => ++calls, [], [])
empty.host.render(); await empty.host.settle()
const beforeFeed = calls
for (const fn of empty.listeners) fn({ type: 'unrelated/event' })
await new Promise(resolve => setTimeout(resolve, 180)); await empty.host.settle()
const afterFeed = calls
const scoped = make(); let courseId = 'course-a'; const next = defer()
scoped.host.component = () => scoped.useLoad(scoped.shell, () => courseId === 'course-a' ? Promise.resolve({ sessionId: 'chat-a', label: 'Course A' }) : next.promise, [courseId], ['learning/sidechat-changed'])
scoped.host.render(); await scoped.host.settle()
const initial = scoped.host.result
courseId = 'course-b'; scoped.host.render(); await scoped.host.settle()
const switching = scoped.host.result
next.reject(new Error('course-b fetch unavailable')); await scoped.host.settle()
const failed = scoped.host.result
const assess = await fs.readFile(`${root}/packages/assess/src/client.tsx`, 'utf8')
const saveCode = assess.slice(assess.indexOf('function saveDraft('), assess.indexOf('\nfunction useTests('))
const storeCode = assess.slice(assess.indexOf('  const store = (problemId:'), assess.indexOf('  /** Every change is saved'))
const flushCode = assess.slice(assess.indexOf('  const flush = async (problemId:'), assess.indexOf('  /** A photo call\'s result:'))
const createDraftHelpers = new Function('shell', 'testId', 'unsaved', 'timers', 'draftOf', `${transpile(`${saveCode}\n${storeCode}\n${flushCode}`)}; return { store, flush }`)
const draft = { text: 'Important answer', finals: [], transcription: { text: 'handwritten answer', confirmed: true } }
const unsaved = { current: new Map([['problem-1', draft]]) }; const timers = { current: new Map() }
const failing = createDraftHelpers({ call: () => Promise.reject(new Error('network offline')) }, 'test-1', unsaved, timers, () => draft)
let surfaced = false; await failing.store('problem-1', draft).catch(() => { surfaced = true })
const inflight = defer(); let saveFinished = false
const helpers = createDraftHelpers({ call: () => inflight.promise }, 'test-1', { current: new Map([['problem-1', draft]]) }, { current: new Map() }, () => draft)
const savePromise = helpers.store('problem-1', draft).then(() => { saveFinished = true })
await helpers.flush('problem-1')
const flushReturnedBeforeSave = !saveFinished
inflight.resolve({ ok: true }); await savePromise
const output = {
  methodology: 'Unmodified function bodies extracted from fixed repository commit; TypeScript removed with installed esbuild. useLoad uses an explicitly limited state/effect harness, not real React or browser.',
  emptyRefreshPrefixes: { beforeFeed, afterFeed, expectedAfterFeed: beforeFeed },
  identityChange: { initial, switching, failed, note: 'CourseSideChat renders retained active.data whenever present, including while loading or after error; it never displays active.error.' },
  autosaveRejection: { surfaced, remainingDirtyEntries: unsaved.current.size, expected: 'error visible and dirty answer retained until acknowledgement' },
  inflightSave: { flushReturnedBeforeSave, expected: false },
}
const json = JSON.stringify(output, (key, value) => typeof value === 'function' ? undefined : value, 2)
await fs.writeFile('__AUDIT_ROOT__/audit/frontend/async-state-result.json', json + '\n')
console.log(json)
