const root = '__AUDIT_ROOT__/learning-agent'
const DSH = `${root}/.tools/dsh/node_modules/@deepseek-ai`
export default {
  root,
  resolve: { alias: [
    { find: /^@deepseek-ai\/(cordis|dsh-llm|dsh-tools)$/, replacement: `${DSH}/$1/lib/index.js` },
    { find: /^@deepseek-ai\/schemastery$/, replacement: `${DSH}/schemastery/lib/index.mjs` },
  ] },
  test: {
    include: ['__AUDIT_ROOT__/audit/frontend/annotation-audit.test.ts'],
    pool: 'forks', maxWorkers: 1, minWorkers: 1,
  },
}
