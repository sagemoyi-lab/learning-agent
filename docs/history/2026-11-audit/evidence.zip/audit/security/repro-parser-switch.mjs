import {LibraryImports} from '../../learning-agent/packages/library/src/imports.ts';

let task={id:'synthetic-job',remoteId:'job-on-A',status:'parsing',fingerprint:'synthetic',message:'parsing',title:'Synthetic'};
const calls=[];
let entered;
const started=new Promise(resolve=>{entered=resolve;});
const makeParser=name=>({where:'本机',cloud:false,async status(id){calls.push({operation:'status',parser:name,id});entered();return {status:'running',files:[]};},async cancel(id){calls.push({operation:'cancel',parser:name,id});}});
const parserA=makeParser('A');
const parserB=makeParser('B');
let selected=parserA;
const store={imports:()=>[task],importTask:()=>task,saveImport:value=>(task=value),byFingerprint:()=>undefined,importFolder:()=>'/tmp/synthetic-no-file-needed'};
const imports=new LibraryImports({emit(){}},store,async()=>selected,1500);
imports.resume();
await started;
selected=parserB;
imports.cancel(task.id);
await new Promise(resolve=>setImmediate(resolve));
console.log(JSON.stringify({calls,result:task.status},null,2));
imports.dispose();
