import { LibraryIndex } from '../../learning-agent/packages/library/src/retrieval.ts';

let enabled = true;
let releaseFirst;
let enteredFirst;
const firstEntered = new Promise(resolve => { enteredFirst = resolve; });
const firstRelease = new Promise(resolve => { releaseFirst = resolve; });
const inserted = new Set();
const allRows = Array.from({length: 257}, (_, i) => ({ id: `chunk-${i}`, section: 'Synthetic', text: `synthetic ${i}` }));
const calls = [];
const embedder = {
  model: 'synthetic@1', dims: 1,
  async embed(texts) {
    calls.push({batch: texts.length, enabled});
    if (calls.length === 1) { enteredFirst(); await firstRelease; }
    return texts.map(() => new Float32Array([1]));
  },
  async rerank() { return []; },
};
const sqlite = { prepare(sql) {
  if (sql.includes('SELECT COUNT(*)')) return { get() { return {n: inserted.size}; } };
  if (sql.includes('SELECT c.id, c.section, c.text')) return { all() { return allRows.filter(row => !inserted.has(row.id)).slice(0, 256); } };
  if (sql.includes('INSERT OR REPLACE INTO library_vectors')) return { run(id) { inserted.add(id); } };
  throw new Error(`Unexpected SQL: ${sql}`);
}};
const store = { count() { return allRows.length; }, sources() { return [{id:'synthetic-source'}]; } };
const index = new LibraryIndex({emit(){}}, store, sqlite, fn => fn(), async () => enabled ? embedder : undefined);
await index.refresh();
await firstEntered;
enabled = false;
await index.refresh();
releaseFirst();
await new Promise(resolve => setImmediate(resolve));
console.log(JSON.stringify({calls, indexedAfterDisabling: inserted.size, displayedState: index.state('synthetic-source')}, null, 2));
index.dispose();
