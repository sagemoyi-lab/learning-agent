import {createServer} from 'node:http';
import {toHtml} from '../../learning-agent/packages/shell/src/client/html.ts';
import {LibraryWeb} from '../../learning-agent/packages/library/src/web/service.ts';
import {rate} from '../../learning-agent/packages/library/src/web/sites.ts';
import {equivalent} from '../../learning-agent/packages/assess/src/grading.ts';
import {math} from '../../learning-agent/packages/assess/src/units.ts';
import {MineruParser} from '../../learning-agent/packages/library/src/parser.ts';

const html = toHtml('<img src=x onerror="document.documentElement.dataset.auditXss=1">\n\n[example](javascript:alert(1))');
console.log(JSON.stringify({test:'markdownActiveContent',html}));

const saved=[];
const rules=[{host:'localhost',authority:'2',createdAt:new Date().toISOString()}];
const server=createServer((req,res)=>{
  if(req.url==='/redirect'){
    res.writeHead(302,{location:`http://127.0.0.1:${server.address().port}/untrusted`});res.end();return;
  }
  res.writeHead(200,{'content-type':'text/html'});
  res.end('<html><title>Synthetic untrusted source</title><body><article><p>'+ 'This is synthetic untrusted educational content. '.repeat(12)+'</p></article></body></html>');
});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
try{
 const base=`http://localhost:${server.address().port}`;
 const final=`http://127.0.0.1:${server.address().port}/untrusted`;
 const store={siteRules:()=>rules,webEntry:()=>undefined,importWebPage:(input)=>{saved.push(input);return{id:'synthetic-source',title:input.title}}};
 const web=new LibraryWeb({emit(){}},store,{}, {provider:()=> 'exa',key:async()=>undefined}, {allowAddress:()=>true});
 const added=await web.add('synthetic-course',[{url:base+'/redirect'}],'teacher');
 console.log(JSON.stringify({test:'redirectAuthority',finalUrl:final,finalUrlRating:rate(final,rules),added,saved:saved.map(item=>({url:item.url,authority:item.authority,title:item.title}))}));
}finally{await new Promise(resolve=>server.close(resolve));}

const matrixResult=equivalent('sum(ones(100,100))','10000');
const sideEffectResult=equivalent('createUnit("auditSyntheticUnit", "2 m")','10000');
console.log(JSON.stringify({test:'unrestrictedExpressionEvaluator',matrixResult,sideEffectResult:sideEffectResult??'undefined',newUnitMetres:math.unit(1,'auditSyntheticUnit').toNumber('m')}));

const actualFetch=globalThis.fetch;
let hops=0;
try{
 globalThis.fetch=async input=>{hops++;return hops<9?new Response(null,{status:302,headers:{location:String(input)}}):Response.json({ok:true});};
 await new MineruParser('https://synthetic.example/api','synthetic-key').check();
 console.log(JSON.stringify({test:'parserRedirectCap',requests:hops,accepted:true}));
}finally{globalThis.fetch=actualFetch;}
