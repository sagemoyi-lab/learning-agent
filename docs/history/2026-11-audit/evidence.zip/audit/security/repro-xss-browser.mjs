import {chromium} from '../../learning-agent/node_modules/playwright-core/index.mjs';
import {toHtml} from '../../learning-agent/packages/shell/src/client/html.ts';
import {writeFileSync} from 'node:fs';

const browser=await chromium.launch({
  executablePath:'__AUDIT_ROOT__/audit/browser-runtime/chromium',
  headless:true,
  args:['--no-sandbox','--disable-dev-shm-usage','--disable-gpu','--no-zygote'],
});
try{
  const page=await browser.newPage();
  const attemptedRequests=[];
  await page.route('**/*', route=>{attemptedRequests.push(route.request().url()); return route.abort();});
  await page.setContent('<!doctype html><meta charset="utf-8"><div id="root"></div>');
  const markdown='<img src="data:image/png;base64,INVALID" onerror="document.documentElement.dataset.auditXss=\'executed\'">';
  const html=toHtml(markdown);
  await page.evaluate(html=>{document.querySelector('#root').innerHTML=html;},html);
  await page.waitForFunction(()=>document.documentElement.dataset.auditXss==='executed',{timeout:3000});
  const result={test:'actualChromiumMarkdownXss',browser:browser.version(),marker:await page.evaluate(()=>document.documentElement.dataset.auditXss),attemptedNetworkRequests:attemptedRequests,webSecurityDisabled:false,html};
  writeFileSync(new URL('./repro-xss-browser.json',import.meta.url),JSON.stringify(result,null,2));
  console.log(JSON.stringify(result,null,2));
}finally{await browser.close();}
